# PROJO GROUP — Step 3 Auth Fix Instructions

## 3 files to copy into your project

---

### File 1 — RegisterPage.jsx
**Copy to:** `frontend/src/pages/auth/RegisterPage.jsx`

**What was fixed:**
- Added email field to the registration form
- OTP now sends to email (not SMS) — matches how the backend works
- Removed call to missing `login()` function, now uses `sendOTP` + `verifyOTP` from AuthContext
- After OTP verified, redirects correctly: Driver → /driver, Admin → /admin, Passenger → /book

---

### File 2 — AuthContext.jsx
**Copy to:** `frontend/src/context/AuthContext.jsx`

**What was fixed:**
- Added `login(user, token, refreshToken)` function
- This was being called by RegisterPage but didn't exist — caused a crash on register

---

### File 3 — admin.routes.js
**Copy to:** `backend/src/routes/admin.routes.js`

**What was fixed:**
- Added `requireRole("ADMIN")` to all admin routes
- Uses the existing `requireRole` from `auth.middleware.js` (already in your project)
- You can delete `requireAdmin.js` from the previous security fix — it's now redundant

---

## After copying the files

Redeploy your backend on Render (or restart locally):
```bash
cd backend
npm start
```

Frontend on Netlify will auto-deploy when you push to GitHub.

---

## Test the auth flow end-to-end

**Register (new user):**
1. Go to /register
2. Choose Passenger or Driver
3. Enter name, phone, email
4. Click Create Account → OTP arrives in email
5. Enter 6-digit code → redirected to /book or /driver

**Login (returning user):**
1. Go to /login
2. Enter phone + email
3. OTP arrives → enter code → redirected correctly

**Admin login:**
1. Login with your admin phone number
2. After OTP → redirected to /admin
3. Non-admin users trying to hit /api/admin/* get 403

---

## Step 3 is now ✅ Complete

Next up: Step 4 — Ride Hailing Core
